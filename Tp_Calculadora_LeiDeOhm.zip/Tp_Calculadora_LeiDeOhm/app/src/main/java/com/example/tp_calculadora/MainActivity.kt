 package com.example.tp_calculadora

 import androidx.appcompat.app.AppCompatActivity
 import android.os.Bundle
 import android.widget.Button
 import android.widget.EditText
 import android.widget.Toast

 class MainActivity : AppCompatActivity() {
     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_main)
         val  edtValor1 = findViewById<EditText>(R.id.edt_valor1)
         val  edtValor2 = findViewById<EditText>(R.id.edt_valor2)
         val  btn = findViewById<Button>(R.id.button)
         val  btn2 = findViewById<Button>(R.id.button2)
         val  btn3 = findViewById<Button>(R.id.button3)

         btn.setOnClickListener{
             val Valor1 = edtValor1.text.toString().toDouble()
             val Valor2 = edtValor2.text.toString().toDouble()
             val voltagem = Valor1 * Valor2
             Toast.makeText(this, "O valor da voltagem é $voltagem", Toast.LENGTH_SHORT).show()
         }
         btn2.setOnClickListener{
             val Valor1 = edtValor1.text.toString().toDouble()
             val Valor2 = edtValor2.text.toString().toDouble()
             val corrente = Valor1 / Valor2
             Toast.makeText(this, "O valor da corrente é $corrente", Toast.LENGTH_SHORT).show()
         }
         btn3.setOnClickListener{
             val Valor1 = edtValor1.text.toString().toDouble()
             val Valor2 = edtValor2.text.toString().toDouble()
             val resistencia = Valor1 / Valor2
             Toast.makeText(this, "O valor da resistencia é $resistencia", Toast.LENGTH_SHORT).show()
         }
     }
 }